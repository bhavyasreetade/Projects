import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Authorizer } from '../entity/Authorizer';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class GuardService {
  url: string = "http://localhost:9090";
  auth: Authorizer = new Authorizer();

  constructor(private h: HttpClient, private router: Router) {}

  canActivate(): boolean {
  let temp = sessionStorage.getItem("token");
  if (temp == null || temp.localeCompare("failed")==0) {
    this.router.navigate(['/login']);
      return false;
  }
  if(sessionStorage.getItem('token')==='admin'){
    return true;
  }
  return false;
  }
}
