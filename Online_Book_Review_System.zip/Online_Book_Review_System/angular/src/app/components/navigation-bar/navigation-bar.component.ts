import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/service/authentication.service';

@Component({
  selector: 'app-navigation-bar',
  templateUrl: './navigation-bar.component.html',
  styleUrls: ['./navigation-bar.component.css']
})
export class NavigationBarComponent {
  logout() {
    this.serv.logout();
  }
  loggedin: boolean=true;
   
    constructor(private router:Router,private serv:AuthenticationService){}
  login() {
    this.router.navigate(['/login']);
  }
  ngOnInit(): void {
    if(sessionStorage.getItem('username')!=null ){
      this.loggedin=false;
    }
}
}