import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchBookByYearComponent } from './search-book-by-year.component';

describe('SearchBookByYearComponent', () => {
  let component: SearchBookByYearComponent;
  let fixture: ComponentFixture<SearchBookByYearComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchBookByYearComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SearchBookByYearComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
