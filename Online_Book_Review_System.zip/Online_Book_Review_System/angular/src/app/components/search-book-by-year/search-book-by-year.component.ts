import { Component } from '@angular/core';
import { Book } from 'src/app/entity/Book';
import { BookService } from 'src/app/service/book.service';
import { SearchBookService } from 'src/app/service/search-book.service';

@Component({
  selector: 'app-search-book-by-year',
  templateUrl: './search-book-by-year.component.html',
  styleUrls: ['./search-book-by-year.component.css']
})
export class SearchBookByYearComponent {
  bookList:Book[]=[];
  search:number=0;
  year:string='';
  statusForEdit: boolean=false;
statusForView: boolean=false;
  constructor(private bookService:BookService,private searchBookService:SearchBookService){}
 
  searchBookByYear():void{
    //console.log("outside if");
    if(this.year){
      //console.log("inside if");
      this.searchBookService.searchBookByYear(this.year).subscribe(
        (b) => {
            if (b && b.length > 0) {
                this.bookList = b;  
                this.statusForView=true;
                //this.search = 1;  
            } else {
                this.bookList = [];  
                //this.search = 2;                    
            }
        });
  }
    else{
      alert("Please Enter Book Title");
    }
  }

editBook(book: Book) {
  this.statusForEdit=true;
  this.statusForView=false;
  sessionStorage.setItem('editableBook', JSON.stringify(book));
  
}
  
  deletedBook:Book=new Book();
  deleteBook(n:string) {
    this.bookService.deleteBook(n).subscribe((a)=>{});
      
  }

  ngOnInit(){
    this.getBooks();
  }

  getBooks(){
    
  }

}
