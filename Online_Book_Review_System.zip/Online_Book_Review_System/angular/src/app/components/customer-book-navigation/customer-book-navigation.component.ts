import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-book-navigation',
  templateUrl: './customer-book-navigation.component.html',
  styleUrls: ['./customer-book-navigation.component.css']
})
export class CustomerBookNavigationComponent {
  statusForSearch:boolean=true;
  statusForAdd:boolean=false;
  statusForSearchBookByTitle:boolean=false;
  statusForSearchBookByAuthor:boolean=false;
  statusForSearchBookBySeller:boolean=false;
  statusForSearchBookByYear:boolean=false;
  statusForView:boolean =false;
  constructor(){
 
  }
  add():void{
    
    if(this.statusForAdd){
      this.statusForAdd=false;

    }
    else{
      this.statusForSearchBookByAuthor=false;
      this.statusForSearchBookByTitle=false;
      this.statusForSearchBookBySeller=false;
      this.statusForSearchBookByYear=false; 
      this.statusForAdd=true;
      this.statusForView=false;
    }
  }
  search():void{
    if(this.statusForSearch){
      this.statusForSearch=false;
    }
    else{
      this.statusForSearch=true;
      
    }

    // this.statusForSearch=false;
}
  searchBookByTitle(){
    console.log("something");
    if(this.statusForSearchBookByTitle){
      this.statusForSearchBookByTitle=false;
      console.log("something if");
    }
    else{
      this.statusForSearchBookByTitle=true;
      this.statusForSearchBookByAuthor=false;
      console.log("something else");
      this.statusForSearchBookBySeller=false;
      this.statusForSearchBookByYear=false; 
      this.statusForAdd=false;
      this.statusForView=false;
    }
    
  }
  searchBookByAuthor(){
    if(this.statusForSearchBookByAuthor){
      this.statusForSearchBookByAuthor=false;
    }
    else{
      this.statusForSearchBookByAuthor=true;

      this.statusForSearchBookByTitle=false;
      this.statusForSearchBookBySeller=false;
      this.statusForSearchBookByYear=false; 
      this.statusForAdd=false;
      this.statusForView=false;
    }
  }
  searchBookBySeller(){
    if(this.statusForSearchBookBySeller){
      this.statusForSearchBookBySeller=false;
    }else{
      this.statusForSearchBookByAuthor=false;
      this.statusForSearchBookByTitle=false;
      this.statusForSearchBookBySeller=true;
      this.statusForSearchBookByYear=false; 
      this.statusForAdd=false;
      this.statusForView=false;
    }
  }
  searchBookByYear(){
    if(this.statusForSearchBookByYear){
      this.statusForSearchBookByYear=false;
    }else{
      this.statusForSearchBookByAuthor=false;
      this.statusForSearchBookByTitle=false;
      this.statusForSearchBookBySeller=false;
      this.statusForSearchBookByYear=true;
      this.statusForView=false; 
      this.statusForAdd=false;
    }
  }

  view(){
    if(this.statusForView){
      this.statusForView=false;
    }
    else{
      this.statusForView=true;
      this.statusForSearchBookByTitle=false;
      this.statusForSearchBookByAuthor=false;
      
      this.statusForSearchBookBySeller=false;
      this.statusForSearchBookByYear=false; 
      this.statusForAdd=false;
    }
  }
ngOnInit(): void {
  //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
  //Add 'implements OnInit' to the class.
  
}

  


}
