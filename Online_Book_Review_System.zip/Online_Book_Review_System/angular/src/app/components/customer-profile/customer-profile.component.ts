import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from 'src/app/entity/Customer';
import { AuthenticationService } from 'src/app/service/authentication.service';

@Component({
  selector: 'app-customer-profile',
  templateUrl: './customer-profile.component.html',
  styleUrls: ['./customer-profile.component.css']
})
export class CustomerProfileComponent {
  constructor(private router:Router,private serv:AuthenticationService){

  }
  account:string|null='';
  customer:Customer=new Customer();
  ngOnInit(): void {
    this.account=sessionStorage.getItem("userId");
    if(this.account){
    this.serv.getUser(this.account).subscribe((a)=>{
      this.customer=a;
      sessionStorage.setItem('CustomerAccountObject',JSON.stringify(a));});
  }

  }


  editProfile():void{
    this.router.navigate(['/editcustomerprofile']);
  }
}
