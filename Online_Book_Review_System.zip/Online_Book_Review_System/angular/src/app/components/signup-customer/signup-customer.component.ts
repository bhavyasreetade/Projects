import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Customer } from 'src/app/entity/Customer';
import { AuthenticationService } from 'src/app/service/authentication.service';

@Component({
  selector: 'app-signup-customer',
  templateUrl: './signup-customer.component.html',
  styleUrls: ['./signup-customer.component.css']
})
export class SignupCustomerComponent {
  customerForm: FormGroup;
  addedCustomer:Customer=new Customer();
  constructor(private r: Router, private service: AuthenticationService) {
    this.customerForm = new FormGroup({
        name: new FormControl("", [Validators.required]),
        email: new FormControl("", [Validators.required, Validators.pattern("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$")]),
        password: new FormControl("",
            [Validators.required,
             Validators.pattern("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=])[A-Za-z\\d@#$%^&+=]{8,}$")
            ]),
    });
}
     signup(customer:any):void{
      if (this.customerForm.valid) {
        this.service.addCustomer(customer).subscribe((c)=>{
          
          this.addedCustomer=c;
          if(this.addedCustomer.email.localeCompare(customer.email)!=0){
            alert("account already exist");
          }
          else if(this.addedCustomer!=null){
            alert("Account created successfully");
          }
        });
        
      }
    }  
}
