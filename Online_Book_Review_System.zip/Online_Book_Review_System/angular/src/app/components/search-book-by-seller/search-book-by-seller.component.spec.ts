import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchBookBySellerComponent } from './search-book-by-seller.component';

describe('SearchBookBySellerComponent', () => {
  let component: SearchBookBySellerComponent;
  let fixture: ComponentFixture<SearchBookBySellerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchBookBySellerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SearchBookBySellerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
