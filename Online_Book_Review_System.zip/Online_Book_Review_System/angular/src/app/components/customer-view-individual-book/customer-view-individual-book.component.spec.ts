import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerViewIndividualBookComponent } from './customer-view-individual-book.component';

describe('CustomerViewIndividualBookComponent', () => {
  let component: CustomerViewIndividualBookComponent;
  let fixture: ComponentFixture<CustomerViewIndividualBookComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerViewIndividualBookComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomerViewIndividualBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
