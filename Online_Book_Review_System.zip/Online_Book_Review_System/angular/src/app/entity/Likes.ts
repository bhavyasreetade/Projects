import { Time } from "@angular/common";
import { Customer } from "./Customer";

 
export class Likes{
    public likeId:number=0;
    public likedCustomer:Customer=new Customer();
    public time:any;
}3