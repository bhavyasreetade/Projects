import { Comments } from "./Comments";
import { Likes } from "./Likes";
import { Review } from "./Review";
 
export class Book{
    
    public bookId:number=0;
    public isbn:any=0;
    public title:string='';
    public author:string='';
    public year:number=0;
    public description:string='';
    public price:any=0;
    public seller:string='';
    public imageLocation:string='';
    public enabled:boolean=true;
    public likes:Likes[]=[];
    public comments:Comments[]=[];
    public reviewList:Review[]=[];
}