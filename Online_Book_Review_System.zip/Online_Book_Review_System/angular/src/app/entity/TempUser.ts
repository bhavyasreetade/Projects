export class TempUser{
    email: string='';
    password: string='';
    role:string='';
  }