export class Admin{
    adminId!:number;
    name!:string;
    email!:string;
    password!:string;
 
   
}