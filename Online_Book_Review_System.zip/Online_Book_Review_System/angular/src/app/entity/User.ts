export class User{
    userId: number=0;
password:string ="";
role: string='';
}