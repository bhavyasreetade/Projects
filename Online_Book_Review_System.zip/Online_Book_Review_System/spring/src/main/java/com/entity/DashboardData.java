package com.entity;
import java.util.List;
import com.entity.Book;

public class DashboardData {
    private List<Book> maxReviewBooks;
    private List<Book> maxLikeBooks;
    private List<Book> maxCommentBooks;
    private double averageLikesPerBook;
    private int bookCount;
    private int likeCount;
    private int commentCount;

    // Getters and Setters
    public List<Book> getMaxReviewBooks() {
        return maxReviewBooks;
    }

    public void setMaxReviewBooks(List<Book> maxReviewBooks) {
        this.maxReviewBooks = maxReviewBooks;
    }

    public List<Book> getMaxLikeBooks() {
        return maxLikeBooks;
    }

    public void setMaxLikeBooks(List<Book> maxLikeBooks) {
        this.maxLikeBooks = maxLikeBooks;
    }

    public List<Book> getMaxCommentBooks() {
        return maxCommentBooks;
    }

    public void setMaxCommentBooks(List<Book> maxCommentBooks) {
        this.maxCommentBooks = maxCommentBooks;
    }

    public double getAverageLikesPerBook() {
        return averageLikesPerBook;
    }

    public void setAverageLikesPerBook(double averageLikesPerBook) {
        this.averageLikesPerBook = averageLikesPerBook;
    }

    public int getBookCount() {
        return bookCount;
    }

    public void setBookCount(int bookCount) {
        this.bookCount = bookCount;
    }

    public int getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(int likeCount) {
        this.likeCount = likeCount;
    }

    public int getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(int commentCount) {
        this.commentCount = commentCount;
    }
}
