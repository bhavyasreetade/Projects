package com.entity;
import java.util.List;
 
import com.fasterxml.jackson.annotation.JsonIgnore;
 
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
@Entity
@Table(name = "book_tbl")
public class Book {
	@Id
	@Column(name = "book_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	int bookId;
	@Column(name = "isbn_number")
	long isbn;
	@Column(name = "book_title")
	String title;
	@Column(name = "book_author")
	String author;
	@Column(name = "book_year")
	int year;
	@Column(name = "book_desc")
	String description;
	@Column(name = "book_price")
	double price;
	@Column(name = "book_seller")
	String seller;
	@Column(name = "image_location")
	String imageLocation;
	@Column(name = "enabled", nullable = false)
    boolean enabled;
	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	List<Likes> likes;
	@ManyToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	List<Comments> comments;
	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	List<Review> reviewList;
	public Book() {
		super();
	}
	public Book(int bookId, long isbn, String title, String author, int year, String description, double price,
			String seller, String imageLocation, boolean enabled, List<Likes> likes, List<Comments> comments,
			List<Review> reviewList) {
		super();
		this.bookId = bookId;
		this.isbn = isbn;
		this.title = title;
		this.author = author;
		this.year = year;
		this.description = description;
		this.price = price;
		this.seller = seller;
		this.imageLocation = imageLocation;
		this.enabled = enabled;
		this.likes = likes;
		this.comments = comments;
		this.reviewList = reviewList;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public long getIsbn() {
		return isbn;
	}
	public void setIsbn(long isbn) {
		this.isbn = isbn;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getSeller() {
		return seller;
	}
	public void setSeller(String seller) {
		this.seller = seller;
	}
	public String getImageLocation() {
		return imageLocation;
	}
	public void setImageLocation(String imageLocation) {
		this.imageLocation = imageLocation;
	}
	public boolean isEnabled() {
		return enabled;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	public List<Likes> getLikes() {
		return likes;
	}
	public void setLikes(List<Likes> likes) {
		this.likes = likes;
	}
	public List<Comments> getComments() {
		return comments;
	}
	public void setComments(List<Comments> comments) {
		this.comments = comments;
	}
	public List<Review> getReviewList() {
		return reviewList;
	}
	public void setReviewList(List<Review> reviewList) {
		this.reviewList = reviewList;
	}
	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", isbn=" + isbn + ", title=" + title + ", author=" + author + ", year="
				+ year + ", description=" + description + ", price=" + price + ", seller=" + seller + ", imageLocation="
				+ imageLocation + ", enabled=" + enabled + ", likes=" + likes + ", comments=" + comments
				+ ", reviewList=" + reviewList + "]";
	} 
	

	
 
}