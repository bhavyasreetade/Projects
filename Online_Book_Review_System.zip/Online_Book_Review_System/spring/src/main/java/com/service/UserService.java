package com.service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.temporal.TemporalUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Admin;
import com.entity.Authorizer;
import com.entity.Customer;
import com.entity.User;
import com.repository.AdminRepositoy;
import com.repository.CustomerRepository;
@Service
public class UserService {
	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	AdminRepositoy adminRepositoy;
	
	public Authorizer login(User user) {
		System.out.println(user.toString());
		Authorizer auth = new Authorizer();
		if(user.getRole().equals("admin")) {
			Admin admin= adminRepositoy.findByEmail(user.getEmail());
			if(admin!=null && admin.getPassword().equals(user.getPassword())) {
				auth.setLoggedInTime(LocalDateTime.now());
				auth.setExpireTime(LocalDateTime.now().plus(Duration.ofHours(24)));
				auth.setToken("admin");
			}
			else {
				auth.setToken("failed");
			}
		}
		else if(user.getRole().equals("customer")) {
			Customer customer= customerRepository.findByEmail(user.getEmail());
			if(customer!=null && customer.getPassword().equals(user.getPassword())) {
				auth.setLoggedInTime(LocalDateTime.now());
				auth.setExpireTime(LocalDateTime.now().plus(Duration.ofHours(24)));
				auth.setToken("customer");
				auth.setUserId(customer.getCustomerId());
			}
			else {
				auth.setToken("failed");
			}
		}
		System.out.println(auth);
		return auth;
	}
	public Customer getCustomer(int id) {
		return customerRepository.findById(id).orElse(null);
		
	}
	public boolean update(Customer customer) {
		if(customerRepository.save(customer)!=null) {
			return true;
		}
		else {
			return false;
		}
		
	}
	
}
