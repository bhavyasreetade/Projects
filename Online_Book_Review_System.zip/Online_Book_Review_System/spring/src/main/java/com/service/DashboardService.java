package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Book;
import com.repository.BookRepository;
import com.repository.CommentRepository;
import com.repository.LikesRepository;
@Service
public class DashboardService {
	@Autowired
	BookRepository bookRepository;
	@Autowired
	CommentRepository commentRepository;
	@Autowired
	LikesRepository likesRepository;
	
	public List<Book> getMaxReviewBook(){
		return bookRepository.getMaxReviewBook();
	}
	public List<Book> getMaxLikeBook(){
		return bookRepository.getMaxLikeBook();
	}
	public List<Book> getMaxCommentBook(){
		return bookRepository.getMaxCommentBook();
	}
	public double getAverageLikesPerBook() {
		return bookRepository.getAverageLikesPerBook();
	}
	public int getBookCount() {
		return bookRepository.findAll().size();
	}
	public int getLikeCount() {
		return likesRepository.findAll().size();
	}
	public int getCommentCount() {
		return commentRepository.findAll().size();
	}
}
