package com.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Customer;
import com.repository.CustomerRepository;
@Service
public class CustomerService {
	@Autowired
	CustomerRepository CustomerRepository;
	
	public Customer addCustomer(Customer customer) {
		Customer cust =CustomerRepository.findByEmail(customer.getEmail());
		if(cust==null)
			return CustomerRepository.save(customer);
		return null;
	}
	public Customer updateCustomer(Customer Customer) {
		return CustomerRepository.save(Customer);
	}
	public List<Customer> getAllCustomers(){
		return CustomerRepository.findAll();
	}
	
	
}
