package com;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.entity.Admin;
import com.entity.Authorizer;
import com.entity.Book;
import com.entity.Comments;
import com.entity.Customer;
import com.entity.Likes;
import com.entity.Review;
import com.entity.User;
import com.repository.AdminRepositoy;
import com.repository.BookRepository;
import com.repository.CustomerRepository;
import com.repository.ReviewRepository;
import com.service.AdminService;
import com.service.BookService;
import com.service.CustomerService;
import com.service.ReviewService;
import com.service.UserService;

@SpringBootTest
class OnlineBookReviewApplicationTests {

	//book service
		//add book
		 @Autowired
		    private BookService bookService;
	 
		    @Autowired
		    private BookRepository bookRepository;
	 
		    private Book book;
	 
		    @BeforeEach
		    public void setaddBook() {
		        book = new Book();
		        book.setTitle("Test Book");
		        book.setAuthor("Test Author");
		        book.setYear(2023);
		    }
	 
		    @Test
		    public void addBook_Success() {
		        // Act
		        Book savedBook = bookService.addBook(book);
	 
		        // Assert
		        assertNotNull(savedBook);
		        assertEquals("Test Book", savedBook.getTitle());
		        assertEquals("Test Author", savedBook.getAuthor());
		        assertEquals(2023, savedBook.getYear());
		        
		        // Verify it is saved in the database
		        assertTrue(bookRepository.findById(savedBook.getBookId()).isPresent());
		    }
		    
		    //add like
		    
		  
		    @Autowired
		    private CustomerRepository customerRepository;
	 
	 
		    private Customer customer;
	 
		    @BeforeEach
		    public void setaddLike() {
		        // Create and save a book
		        book = new Book();
		        book.setTitle("Test Book");
		        book.setAuthor("Test Author");
		        book.setYear(2023);
		        book = bookRepository.save(book);
	 
		        // Create and save a customer
		        customer = new Customer();
		        customer.setName("Test Customer");
		        customer = customerRepository.save(customer);
		    }
	 
		    @Test
		    public void addLike_Success() {
		        // Act
		        Book updatedBook = bookService.addLike(customer.getCustomerId(), book.getBookId());
	 
		        // Assert
		        assertNotNull(updatedBook);
		        assertEquals(book.getBookId(), updatedBook.getBookId());
	 
		        List<Likes> likes = updatedBook.getLikes();
		        assertNotNull(likes);
		        assertEquals(1, likes.size());
		        assertEquals(customer.getCustomerId(), likes.get(0).getLikedCustomer().getCustomerId());
		    }
		    //add comment
		    private Book testBook;
		    private Customer testCustomer;
		    @BeforeEach
		    public void setaddComment() {
		        testCustomer = new Customer();
		        testCustomer.setName("Test Customer");
		        customerRepository.save(testCustomer);
	 
		        // Create a test book
		        testBook = new Book();
		        testBook.setTitle("Test Book");
		        testBook.setComments(new ArrayList<>());
		        bookRepository.save(testBook);
		    }
	 
		    @Test
		    public void addComment_ReturnsBookWithComment_WhenValidInput() {
		        // Arrange
		        String commentText = "This is a comment";
	 
		        // Act
		        Book updatedBook = bookService.addComment(testCustomer.getCustomerId(), testBook.getBookId(), commentText);
	 
		        // Assert
		        assertNotNull(updatedBook);
		        List<Comments> comments = updatedBook.getComments();
		        assertNotNull(comments);
		        assertEquals(1, comments.size());
		        assertEquals(commentText, comments.get(0).getComment());
		        assertEquals(testCustomer.getCustomerId(), comments.get(0).getCustomer().getCustomerId());
		        assertNotNull(comments.get(0).getCommentTime());
		    }
		    
		    //add review
		    @BeforeEach
		    public void setaddReview() {
		        // Clear repositories
		        
	 
		        // Create a test customer
		        testCustomer = new Customer();
		        testCustomer.setName("Test Customer");
		        customerRepository.save(testCustomer);
	 
		        // Create a test book
		        testBook = new Book();
		        testBook.setTitle("Test Book");
		        testBook.setReviewList(new ArrayList<>());
		        bookRepository.save(testBook);
		    }
	 
		    @Test
		    public void addReview_ReturnsSavedReview_WhenValidInput() {
		        // Arrange
		        String reviewText = "This is a great book!";
		        int rating = 5;
	 
		        // Act
		        Review savedReview = bookService.addReview(testCustomer.getCustomerId(), testBook.getBookId(), reviewText, rating);
	 
		        // Assert
		        assertNotNull(savedReview);
		        assertEquals(reviewText, savedReview.getReviewText());
		        assertEquals(rating, savedReview.getRating());
	 
		        // Verify that the review was added to the book
		        Book updatedBook = bookRepository.findById(testBook.getBookId()).orElse(null);
		        assertNotNull(updatedBook);
		        List<Review> reviews = updatedBook.getReviewList();
		        assertNotNull(reviews);
		        
		      
		    }
		    //getBookbyTitle
	 
		    @BeforeEach
		    public void setgetbyTtile() {
		       
	 
		        // Adding sample books to the repository
		        Book book1 = new Book();
		        book1.setTitle("The Great Gatsby");
		        bookRepository.save(book1);
	 
		        Book book2 = new Book();
		        book2.setTitle("Moby Dick");
		        bookRepository.save(book2);
	 
		        Book book3 = new Book();
		        book3.setTitle("The Great Gatsby"); // Duplicate title for testing
		        bookRepository.save(book3);
		    }
	 
		    @Test
		    public void getBookByTitle_ReturnsBooks_WhenTitleExists() {
		        // Arrange
		        String title = "The Great Gatsby";
	 
		        // Act
		        List<Book> foundBooks = bookService.getBookByTitle(title);
	 
		        // Assert
		        assertNotNull(foundBooks);
		     
		        assertTrue(foundBooks.stream().allMatch(book -> book.getTitle().equals(title)));
		    }
		    
		    @BeforeEach
		    public void setgetbyYear() {
		      
	 
		        // Adding sample books to the repository
		        Book book1 = new Book();
		        book1.setTitle("The Great Gatsby");
		        book1.setYear(1925);
		        bookRepository.save(book1);
	 
		        Book book2 = new Book();
		        book2.setTitle("Moby Dick");
		        book2.setYear(1851);
		        bookRepository.save(book2);
	 
		        Book book3 = new Book();
		        book3.setTitle("To Kill a Mockingbird");
		        book3.setYear(1960);
		        bookRepository.save(book3);
		    }
	 
		    @Test
		    public void getBookByYear_ReturnsBooks_WhenYearExists() {
		        // Arrange
		        int year = 1925;
	 
		        // Act
		        List<Book> foundBooks = bookService.getBookByYear(year);
	 
		        // Assert
		        assertNotNull(foundBooks);
		        Book  b = null;
		        for(Book book:foundBooks) {
		        	if(book.getTitle().equals("The Great Gatsby"))
		        		b=book;
		        }
		        assertEquals("The Great Gatsby", b.getTitle());
		    }
		    
		    @BeforeEach
		    public void setEnabledBooks() {
		   
	 
		       
		        Book book1 = new Book();
		        book1.setTitle("The Great Gatsby");
		        book1.setEnabled(true);
		        bookRepository.save(book1);
	 
		        Book book2 = new Book();
		        book2.setTitle("Moby Dick");
		        book2.setEnabled(false);
		        bookRepository.save(book2);
	 
		        Book book3 = new Book();
		        book3.setTitle("To Kill a Mockingbird");
		        book3.setEnabled(true);
		        bookRepository.save(book3);
		    }
	 
		    @Test
		    public void getAllEnabledBooks_ReturnsOnlyEnabledBooks() {
		        // Act
		        List<Book> enabledBooks = bookService.findByEnabledTrue();
	 
		        // Assert
		        assertNotNull(enabledBooks);
		        assertTrue(enabledBooks.stream().allMatch(Book::isEnabled)); // All books should be enabled
		    }
	 
	 
	 
		    
		    
	 
	 
		   //admin service
		   //add admin
		    @Autowired
		    private AdminService adminService;
	 
		    @Autowired
		    private AdminRepositoy adminRepository;
	 
		    private Admin admin;
	 
		    @BeforeEach
		    public void setaddAd() {
		        // Create a new admin instance
		        admin = new Admin();
		        admin.setName("Test Admin");
		        admin.setEmail("testadmin@example.com");
		        // Add other necessary fields...
		    }
	 
		    @Test
		    public void add_Success() {
		        // Act
		        Admin savedAdmin = adminService.add(admin);
	 
		        // Assert
		        assertNotNull(savedAdmin);
		        assertEquals(admin.getName(), savedAdmin.getName());
		        assertEquals(admin.getEmail(), savedAdmin.getEmail());
		        // Add more assertions as necessary for other fields...
		    }
		    
		    //update admin
		   
	 
		    @BeforeEach
		    public void setupdateAdmin() {
		        // Create and save a new admin instance
		        admin = new Admin();
		        admin.setName("Test Admin");
		        admin.setEmail("testadmin@example.com");
		        admin = adminRepository.save(admin);  // Save to get an ID for updating
		    }
	 
		    @Test
		    public void update_Success() {
		        // Update admin's name
		        admin.setName("Updated Admin");
	 
		        // Act
		        Admin updatedAdmin = adminService.update(admin);
	 
		        // Assert
		        assertNotNull(updatedAdmin);
		        assertEquals("Updated Admin", updatedAdmin.getName());
		        assertEquals(admin.getEmail(), updatedAdmin.getEmail());
		    }
		    
		    //customer service
		    //add customer
		    
		    @Autowired
		    private CustomerService customerService;
	 
		    @BeforeEach
		    public void setaddCustomer() {
		        // Create a new customer instance
		        customer = new Customer();
		        customer.setName("Test Customer");
		        customer.setEmail("testcustomer@example.com");
		    }
	 
		    @Test
		    public void addCustomer_Success() {
		        // Act
		        Customer addedCustomer = customerService.addCustomer(customer);
	 
		        // Assert
		        assertNotNull(addedCustomer);
		        assertNotNull(addedCustomer.getCustomerId()); // Ensure that the ID is generated
		        assertEquals("Test Customer", addedCustomer.getName());
		        
		    }
		    
		    //get all reviews
		    
		    @Autowired
		    private ReviewService reviewService;
	 
		    @Autowired
		    private ReviewRepository reviewRepository;
	 
		    @BeforeEach
		    public void setgetReviews() {
		        // Clean the database and add some initial reviews for testing
		        
		        Review review1 = new Review();
		        review1.setReviewText("Great book!");
		        review1.setRating(5);
		        reviewRepository.save(review1);
	 
		        Review review2 = new Review();
		        review2.setReviewText("Not bad.");
		        review2.setRating(3);
		        reviewRepository.save(review2);
		    }
	 
		    @Test
		    public void getAllReviews_ReturnsAllReviews() {
		        // Act
		        List<Review> result = reviewService.getAllReviews();
	 
		        // Assert
		        assertNotNull(result);
		       
		        assertEquals("Great book!", result.get(0).getReviewText());
		        assertEquals("Not bad.", result.get(1).getReviewText());
		    }
	 
		    @Test
		    public void getAllReviews_ReturnsEmptyList_WhenNoReviews() {
		       
	 
		        // Act
		        List<Review> result = reviewService.getAllReviews();
	 
		        // Assert
		        assertNotNull(result);
		        
		    }
		    @Autowired
		    private UserService userService;
		    //user service
		    @BeforeEach
		    public void setUp() {
		        // Prepare data for tests
		        Admin admin = new Admin();
		        admin.setEmail("admin@example.com");
		        admin.setPassword("password");
		        adminRepository.save(admin);
	 
		        Customer customer = new Customer();
		        customer.setEmail("customer@example.com");
		        customer.setPassword("password");
		        customerRepository.save(customer);
		    }
	 
		    @Test
		    public void login_Admin_Success() {
		        // Arrange
		        User user = new User("admin@example.com", "admin", "password");
	 
		        // Act
		        Authorizer auth = userService.login(user);
	 
		        // Assert
		        assertNotNull(auth);
		        assertEquals("admin", auth.getToken());
		        assertNotNull(auth.getLoggedInTime());
		        assertNotNull(auth.getExpireTime());
		        assertTrue(auth.getExpireTime().isAfter(LocalDateTime.now()));
		    }
	 
		    @Test
		    public void login_Admin_Failure() {
		        // Arrange
		        User user = new User("admin@example.com", "admin", "wrongpassword");
	 
		        // Act
		        Authorizer auth = userService.login(user);
	 
		        // Assert
		        assertNotNull(auth);
		        assertEquals("failed", auth.getToken());
		    }
	 
		    @Test
		    public void login_Customer_Success() {
		        // Arrange
		        User user = new User("customer@example.com", "customer", "password");
	 
		        // Act
		        Authorizer auth = userService.login(user);
	 
		        // Assert
		        assertNotNull(auth);
		        assertEquals("customer", auth.getToken());
		        assertNotNull(auth.getLoggedInTime());
		        assertNotNull(auth.getExpireTime());
		        assertTrue(auth.getExpireTime().isAfter(LocalDateTime.now()));
		    }
	 
		    @Test
		    public void login_Customer_Failure() {
		        // Arrange
		        User user = new User("customer@example.com", "customer", "wrongpassword");
	 
		        // Act
		        Authorizer auth = userService.login(user);
	 
		        // Assert
		        assertNotNull(auth);
		        assertEquals("failed", auth.getToken());
		    }	    

}
